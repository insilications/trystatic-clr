trystatic-clr
==================================

trystatic-clr
