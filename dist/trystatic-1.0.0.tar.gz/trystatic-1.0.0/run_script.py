import trystatic
from trystatic import __main__
__main__.main()
